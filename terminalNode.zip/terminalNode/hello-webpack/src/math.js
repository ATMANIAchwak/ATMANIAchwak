export const add = (a, b) => a + b;
export const mult = (a, b) => a * b;
export const div = (a, b) => a / b; 
