const a = require('a.js')

const array = ['bonjour', 'au revoir', 11, 232, 7, 89]

for (let i = 0; i < array.length; i++) {
  const element = array[i]
}

function bonjour(prenom) {
  const age = 25
}

const age = 30
