import {add, mult} from './math';

const res = add(1, 2);
console.log(res, mult(1, 2));
console.log(div(1, 2));